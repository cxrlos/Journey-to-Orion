    var rootRef = firebase.database().ref().child("sessions");
    rootRef.on("child_added", snap =>{
        var code = snap.child("classroom_code").val();
        var motive = snap.child("motive").val();
        var name = snap.child("name").val();
        var end = snap.child("time_end").val();
        var start = snap.child("time_start").val();
        var date = snap.child("date").val();

        $("#table_sessions").append("<tr class='row100 body'></tr><td class='cell100 column1'>"+name+"</td>");

        $("#second_table_sessions").append("<tr class='row100 body'><td class='cell100 column2'>" 
        +code+"</td><td class='cell100 column3'>"+date+"</td><td class='cell100 column4'>"
        +start+"</td><td class='cell100 column5'>"+end+"</td><td class='cell100 column6'>"
        +motive+"</td><td class='cell100 column7'>");

    });